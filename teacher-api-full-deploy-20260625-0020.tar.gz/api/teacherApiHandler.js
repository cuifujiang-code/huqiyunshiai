import { isSupabaseAdminConfigured, uploadQuestionImage } from '../server/supabaseAdmin.js'
import * as questionBank from '../server/teacher/questionBankStore.js'
import { importQuestionsFromExcel } from '../server/teacher/questionExcelImport.js'
import { splitExamToQuestions } from '../server/teacher/questionImportService.js'
import { orchestrateAITask } from '../server/aiOrchestrator.js'
import * as lessonPlan from '../server/teacher/lessonPlanStore.js'
import * as handout from '../server/teacher/handoutStore.js'
import * as book from '../server/teacher/bookStore.js'
import * as bookAi from '../server/teacher/bookAi.js'
import { formatBookLayoutWithAi } from '../server/teacher/bookFormatAi.js'
import { callDeepSeekAI } from '../server/deepseekClient.js'
import { repairJSON } from '../server/batch/jsonRepairEngine.js'
import { normalizeTeacherPath } from '../server/urlUtil.js'
import { getStatsForQuestion, getAnalyticsDashboard } from '../server/teacher/questionStatsStore.js'
import {
  generateVariantQuestionForId,
  recommendSimilarQuestionsForId,
  generateWrongAnswerExplanationForId,
  batchGenerateAnalysis,
} from '../server/teacher/questionAiService.js'

function requireTeacher(body, query) {
  const teacherId = body?.teacherId?.trim() || query?.teacherId?.trim()
  if (!teacherId) throw new Error('缺少 teacherId')
  return teacherId
}

function notConfigured(res) {
  return res.status(503).json({ success: false, message: '请配置 VITE_SUPABASE_URL 与 SUPABASE_SERVICE_ROLE_KEY' })
}

function needsSupabase(path) {
  return !path.startsWith('questions-import/')
    && path !== 'questions/generate'
    && path !== 'questions/ocr-correct'
}

/** 独立教师 API 路由（部署于 api.huqiyunshiai.online） */
export async function handleTeacherApi(req, res, pathSegments = []) {
  const method = req.method
  const path = normalizeTeacherPath(pathSegments)
  const body = req.body ?? {}
  const query = req.query ?? {}

  console.log('[teacherApi] 路由', { method, path, rawSegments: pathSegments, url: req.url })

  if (!path) {
    return res.status(404).json({ success: false, message: '未知路由: （空路径）' })
  }

  if (needsSupabase(path) && !isSupabaseAdminConfigured()) return notConfigured(res)

  try {
    if (path === 'questions' && method === 'GET') {
      const teacherId = query.teacherId
      if (!teacherId) return res.status(400).json({ success: false, message: '缺少 teacherId' })
      console.log('[teacherApi] 查询题库', { teacherId, query })
      const result = await questionBank.listQuestions(teacherId, query)
      console.log('[teacherApi] 题库结果', { teacherId, total: result.total, itemCount: result.items?.length ?? 0 })
      return res.status(200).json({ success: true, ...result })
    }

    if (path === 'analytics/dashboard' && method === 'GET') {
      const teacherId = query.teacherId
      if (!teacherId) return res.status(400).json({ success: false, message: '缺少 teacherId' })
      const data = await getAnalyticsDashboard(teacherId, query)
      return res.status(200).json({ success: true, ...data })
    }

    if (path === 'questions/ai/batch-analysis' && method === 'POST') {
      const teacherId = requireTeacher(body, query)
      const result = await batchGenerateAnalysis(teacherId, body.ids ?? [])
      return res.status(200).json({ success: true, ...result })
    }

    if (path === 'questions' && method === 'POST') {
      const teacherId = requireTeacher(body, query)
      const data = await questionBank.createQuestion(teacherId, body)
      return res.status(200).json({ success: true, question: data })
    }

    const questionPathParts = path.split('/')
    if (questionPathParts[0] === 'questions' && questionPathParts.length >= 3) {
      const qid = questionPathParts[1]
      const subPath = questionPathParts.slice(2).join('/')

      if (subPath === 'versions' && method === 'GET') {
        const teacherId = query.teacherId
        if (!teacherId) return res.status(400).json({ success: false, message: '缺少 teacherId' })
        const versions = await questionBank.fetchQuestionVersions(teacherId, qid)
        return res.status(200).json({ success: true, versions })
      }

      if (subPath === 'versions/restore' && method === 'POST') {
        const teacherId = requireTeacher(body, query)
        const versionId = body.versionId?.trim()
        if (!versionId) return res.status(400).json({ success: false, message: '缺少 versionId' })
        const question = await questionBank.restoreQuestionToVersion(teacherId, qid, versionId)
        return res.status(200).json({ success: true, question })
      }

      if (subPath === 'stats' && method === 'GET') {
        const teacherId = query.teacherId
        if (!teacherId) return res.status(400).json({ success: false, message: '缺少 teacherId' })
        const stats = await getStatsForQuestion(qid)
        return res.status(200).json({ success: true, stats })
      }

      if (subPath === 'ai/variant' && method === 'POST') {
        const teacherId = requireTeacher(body, query)
        const variant = await generateVariantQuestionForId(teacherId, qid)
        return res.status(200).json({ success: true, variant })
      }

      if (subPath === 'ai/similar' && method === 'GET') {
        const teacherId = query.teacherId
        if (!teacherId) return res.status(400).json({ success: false, message: '缺少 teacherId' })
        const limit = query.limit ? Number(query.limit) : 8
        const similar = await recommendSimilarQuestionsForId(teacherId, qid, limit)
        return res.status(200).json({ success: true, similar })
      }

      if (subPath === 'ai/explanation' && method === 'POST') {
        const teacherId = requireTeacher(body, query)
        const explanation = await generateWrongAnswerExplanationForId(teacherId, qid)
        return res.status(200).json({ success: true, explanation })
      }
    }

    if (path.startsWith('questions/') && method === 'PUT') {
      const id = path.split('/')[1]
      const teacherId = requireTeacher(body, query)
      const data = await questionBank.updateQuestion(teacherId, id, body)
      return res.status(200).json({ success: true, question: data })
    }

    if (path === 'questions' && method === 'DELETE') {
      const teacherId = requireTeacher(body, query)
      await questionBank.deleteQuestions(teacherId, body.ids ?? [])
      return res.status(200).json({ success: true })
    }

    if (path === 'questions/batch-tags' && method === 'POST') {
      const teacherId = requireTeacher(body, query)
      await questionBank.updateQuestionsTags(teacherId, body.ids ?? [], body.tags ?? [])
      return res.status(200).json({ success: true })
    }

    if (path === 'questions/batch-visibility' && method === 'POST') {
      const teacherId = requireTeacher(body, query)
      const vis = body.visibility === 'public' ? 'public' : 'personal'
      await questionBank.updateQuestionsVisibility(teacherId, body.ids ?? [], vis)
      return res.status(200).json({ success: true })
    }

    if (path === 'questions/batch' && method === 'POST') {
      const teacherId = requireTeacher(body, query)
      const result = await questionBank.createQuestionsBatch(teacherId, body.questions ?? [])
      const questions = Array.isArray(result) ? result : result.items
      const topicTagging = Array.isArray(result) ? undefined : result.topicTagging
      return res.status(200).json({ success: true, questions, topicTagging })
    }

    if (path === 'questions/import' && method === 'POST') {
      const teacherId = requireTeacher(body, query)
      const { fileBase64, fileName } = body
      if (!fileBase64) {
        return res.status(400).json({ success: false, message: '请上传 Excel 文件' })
      }
      const buffer = Buffer.from(fileBase64, 'base64')
      const result = await importQuestionsFromExcel(teacherId, buffer)
      return res.status(200).json({ success: true, ...result })
    }

    if (path === 'questions-import/split' && method === 'POST') {
      const { examFileBase64, examFileName, subject, grade } = body
      if (!examFileBase64 || !examFileName) {
        return res.status(400).json({ success: false, message: '请上传试卷文件' })
      }
      const buffer = Buffer.from(examFileBase64, 'base64')
      const questions = await splitExamToQuestions(buffer, examFileName, { subject, grade })
      return res.status(200).json({ success: true, questions })
    }

    if (path === 'questions/upload-image' && method === 'POST') {
      const teacherId = requireTeacher(body, query)
      const { fileBase64, fileName, mimeType } = body
      if (!fileBase64) {
        return res.status(400).json({ success: false, message: '缺少 fileBase64' })
      }
      const buffer = Buffer.from(fileBase64, 'base64')
      const url = await uploadQuestionImage(teacherId, buffer, mimeType || 'image/png', fileName || 'image.png')
      return res.status(200).json({ success: true, url })
    }

    if (path === 'questions/ocr-correct' && method === 'POST') {
      const { content, options, answer, analysis, subject, grade, question_type } = body
      const system = `你是 K12 题目 OCR/LaTeX 校正专家。修复 OCR 乱码、错误字符、缺失标点、LaTeX 公式格式（行内 $...$，独立 $$...$$），保留原意与选项结构。只输出 JSON：{"content":"...","options":["..."],"answer":"...","analysis":"..."}`
      const user = JSON.stringify({ content, options, answer, analysis, subject, grade, question_type })
      const raw = await callDeepSeekAI(system, user)
      const fixed = repairJSON(raw)
      return res.status(200).json({
        success: true,
        question: {
          content: String(fixed.content ?? content ?? ''),
          options: Array.isArray(fixed.options) ? fixed.options.map(String) : (options ?? []),
          answer: String(fixed.answer ?? answer ?? ''),
          analysis: String(fixed.analysis ?? analysis ?? ''),
        },
      })
    }

    if (path === 'questions/topics' && method === 'GET') {
      const teacherId = query.teacherId
      if (!teacherId) return res.status(400).json({ success: false, message: '缺少 teacherId' })
      const subject = query.subject || undefined
      const grade = query.grade || undefined
      const result = await questionBank.listTopics(teacherId, subject, grade)
      return res.status(200).json({ success: true, ...result })
    }

    if (path === 'questions/stats' && method === 'GET') {
      const teacherId = query.teacherId
      if (!teacherId) return res.status(400).json({ success: false, message: '缺少 teacherId' })
      const stats = await questionBank.getQuestionStats(teacherId)
      return res.status(200).json({ success: true, stats })
    }

    if (path === 'questions/generate' && method === 'POST') {
      const { subject, grade, question_type, difficulty, knowledge_point } = body
      const prompt = `生成一道${grade}${subject}${question_type}，难度${difficulty}，知识点${knowledge_point}。返回 JSON: content, options, answer, analysis, knowledge_point`
      const content = await callDeepSeekAI('只输出 JSON', prompt)
      const q = repairJSON(content)
      return res.status(200).json({
        success: true,
        question: {
          subject,
          grade,
          question_type,
          difficulty,
          knowledge_point: q.knowledge_point || knowledge_point,
          content: q.content,
          options: q.options ?? [],
          answer: q.answer,
          analysis: q.analysis,
          source: 'AI生成',
          tags: [],
        },
      })
    }

    if (path === 'exam-builder' && method === 'POST') {
      const teacherId = requireTeacher(body, query)
      const outcome = await orchestrateAITask('exam-builder', { teacherId, config: body })
      if (!outcome.success) {
        return res.status(500).json({ success: false, message: outcome.error || '组卷失败' })
      }
      return res.status(200).json({
        success: true,
        exam: outcome.result?.exam,
        reviewRequired: outcome.result?.reviewRequired ?? false,
        validation: outcome.result?.validation,
        meta: outcome.meta,
      })
    }

    if (path === 'lesson-plans' && method === 'GET') {
      const data = await lessonPlan.listLessonPlans(query.teacherId)
      return res.status(200).json({ success: true, plans: data })
    }

    if (path === 'lesson-plans' && method === 'POST') {
      const teacherId = requireTeacher(body, query)
      const data = await lessonPlan.saveLessonPlan(teacherId, body)
      return res.status(200).json({ success: true, plan: data })
    }

    if (path.startsWith('lesson-plans/') && method === 'DELETE') {
      const id = path.split('/')[1]
      await lessonPlan.deleteLessonPlan(body.teacherId || query.teacherId, id)
      return res.status(200).json({ success: true })
    }

    if (path === 'handouts' && method === 'GET') {
      const data = await handout.listHandouts(query.teacherId)
      return res.status(200).json({ success: true, handouts: data })
    }

    if (path.startsWith('handouts/') && method === 'GET') {
      const id = path.split('/')[1]
      const data = await handout.getHandout(query.teacherId, id)
      return res.status(200).json({ success: true, handout: data })
    }

    if (path === 'handouts' && method === 'POST') {
      if (body.action === 'generate') {
        const draft = await handout.generateHandoutDraft(body.mode, body)
        return res.status(200).json({ success: true, draft })
      }
      if (body.action === 'knowledge-summary') {
        const summary = await handout.generateKnowledgeSummary(body)
        return res.status(200).json({ success: true, summary })
      }
      const teacherId = requireTeacher(body, query)
      const data = await handout.saveHandout(teacherId, body)
      return res.status(200).json({ success: true, handout: data })
    }

    if (path.startsWith('handouts/') && method === 'DELETE') {
      const id = path.split('/')[1]
      await handout.deleteHandout(body.teacherId || query.teacherId, id)
      return res.status(200).json({ success: true })
    }

    if (path === 'books' && method === 'GET') {
      const data = await book.listBooks(query.teacherId)
      return res.status(200).json({ success: true, books: data })
    }

    if (path.startsWith('books/') && method === 'GET') {
      const id = path.split('/')[1]
      const data = await book.getBook(query.teacherId, id)
      return res.status(200).json({ success: true, book: data })
    }

    if (path === 'books/knowledge-graph' && method === 'POST') {
      requireTeacher(body, query)
      const graph = await bookAi.generateKnowledgeGraph(body.questions ?? [])
      return res.status(200).json({ success: true, graph })
    }

    if (path === 'books/foreword-epilogue' && method === 'POST') {
      requireTeacher(body, query)
      const { foreword, epilogue } = await bookAi.generateForewordEpilogue(body)
      return res.status(200).json({ success: true, foreword, epilogue })
    }

    if (path === 'books/format-layout' && method === 'POST') {
      requireTeacher(body, query)
      const chapters = await formatBookLayoutWithAi({
        chapters: body.chapters ?? [],
        subject: body.subject,
        title: body.title,
        grade: body.grade,
        level: body.level,
      })
      return res.status(200).json({ success: true, chapters })
    }

    if (path === 'books/export-pdf' && method === 'POST') {
      const { html, title, coverStyle, outline, studentHtml, teacherHtml } = body || {}
      if (!html && !studentHtml && !teacherHtml) {
        return res.status(400).json({ error: '缺少 html 参数' })
      }

      const options = { title: title || '教辅书', coverStyle: coverStyle || 'academic', outline: outline || [] }

      try {
        const { generateBookPdf, generateBookDualPdf } = await import('../server/teacher/bookPdfExporter.js')

        // 双版本导出
        if (studentHtml && teacherHtml) {
          const { studentBuffer, teacherBuffer } = await generateBookDualPdf({
            htmlStudent: studentHtml,
            htmlTeacher: teacherHtml,
            options,
          })
          return res.status(200).json({
            success: true,
            studentBase64: studentBuffer.toString('base64'),
            teacherBase64: teacherBuffer.toString('base64'),
          })
        }

        // 单版本导出
        const pdfBuffer = await generateBookPdf({ html, options })
        res.setHeader('Content-Type', 'application/pdf')
        res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(options.title)}.pdf"`)
        res.setHeader('Content-Length', pdfBuffer.length)
        return res.status(200).send(pdfBuffer)
      } catch (err) {
        console.error('[books/export-pdf] 导出失败:', err.message)
        return res.status(503).json({
          success: false,
          message: `PDF 导出服务不可用: ${err.message}`,
        })
      }
    }

    if (path === 'books' && method === 'POST') {
      const teacherId = requireTeacher(body, query)
      const data = await book.saveBook(teacherId, body)
      return res.status(200).json({ success: true, book: data })
    }

    if (path.startsWith('books/') && method === 'DELETE') {
      const id = path.split('/')[1]
      await book.deleteBook(body.teacherId || query.teacherId, id)
      return res.status(200).json({ success: true })
    }

    return res.status(404).json({ success: false, message: `未知路由: ${path}` })
  } catch (error) {
    console.error('[teacherApi]', path, error)
    return res.status(500).json({
      success: false,
      message: error instanceof Error ? error.message : '服务器错误',
    })
  }
}
